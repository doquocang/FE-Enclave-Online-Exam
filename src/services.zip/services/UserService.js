import axios from "./Customize-axios";

const loginApi = (username, password) => {
  return axios.post("/auth/token", { username, password }).then((result) => {
    console.log(result);
  });
  // return axios.post("http://172.16.75.32:8080/swagger-ui/index.html#/authentication-controller/authenticate", {username, password})
};

export { loginApi };
